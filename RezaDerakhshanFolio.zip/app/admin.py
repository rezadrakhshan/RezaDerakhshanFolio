from django.contrib import admin
from .models import Skills, Experience, Eduction, Testimonial, Category, Project

# Register your models here.


admin.site.register(Skills)
admin.site.register(Experience)
admin.site.register(Eduction)
admin.site.register(Testimonial)
admin.site.register(Category)
admin.site.register(Project)
